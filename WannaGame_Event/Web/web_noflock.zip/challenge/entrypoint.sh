#!/bin/sh
set -e
flag=${FLAG}
if [ -z "$flag" ]; then
  flag=flag{test_flag}
fi
printf '%s' "$flag" >/flag
chown root:root /flag
chmod 0400 /flag
php-fpm
nginx -c /conf/nginx.conf -g 'daemon off;'
