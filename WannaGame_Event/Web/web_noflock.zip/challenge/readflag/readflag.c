#include <stdio.h>

int main(void)
{
    FILE *f = fopen("/flag", "r");
    char buf[4096];
    size_t n;
    if (!f) {
        return 1;
    }
    n = fread(buf, 1, sizeof(buf) - 1, f);
    buf[n] = '\0';
    fclose(f);
    fputs(buf, stdout);
    return 0;
}
