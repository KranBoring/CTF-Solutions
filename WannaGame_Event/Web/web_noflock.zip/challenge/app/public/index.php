<?php
require __DIR__ . '/../vendor/autoload.php';

use Monolog\Handler\StreamHandler;
use Monolog\Logger;

const ROOT_HASH = '$2y$12$ZJ/VVi7VHWve2rf5MQ9tFecUAWt9Jy6mrvhezhKa6FKbwF8.keIFO';
const FLAG_NOTE_ID = 'f1a6c0de5eedf1a6';
const SHARE_DIR = '/tmp/sticky/shares';

$logger = new Logger('notes');
$logger->pushHandler(new StreamHandler('/tmp/app.log', Logger::WARNING));

session_start();

$route = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

function new_id(): string
{
    return bin2hex(random_bytes(8));
}

function share_file(string $id): string
{
    return SHARE_DIR . '/' . $id . '.json';
}

function share_load(string $id): ?array
{
    if (!preg_match('/^[a-f0-9]{16}$/', $id)) {
        return null;
    }
    if ($id === FLAG_NOTE_ID) {
        return [
            'id' => FLAG_NOTE_ID,
            'title' => 'Flag',
            'body' => '',
            'password_hash' => ROOT_HASH,
            'special' => true,
        ];
    }
    $file = share_file($id);
    if (!is_file($file)) {
        return null;
    }
    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : null;
}

function share_store(array $note): void
{
    if (!is_dir(SHARE_DIR)) {
        @mkdir(SHARE_DIR, 0700, true);
    }
    file_put_contents(share_file($note['id']), json_encode($note, JSON_INVALID_UTF8_SUBSTITUTE));
    @chmod(share_file($note['id']), 0600);
}

function head(string $title): void
{
    ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($title) ?></title>
<link rel="stylesheet" href="/style.css">
</head>
<body>
<div class="wrap">
<span class="eyebrow">Sticky notes</span>
<?php
}

function foot(): void
{
    ?></div>
</body>
</html><?php
}

if ($route === '/note' && $method === 'POST') {
    $title = trim((string)($_POST['title'] ?? ''));
    $body = (string)($_POST['body'] ?? '');
    if (strlen($body) > 4096) {
        http_response_code(422);
        exit('note too long');
    }
    $id = new_id();
    $_SESSION['notes'][$id] = [
        'title' => $title === '' ? 'Untitled' : $title,
        'body' => $body,
        'shared' => false,
        'created' => time(),
    ];
    $logger->info('note saved', ['id' => $id]);
    header('Location: /note?id=' . $id);
    exit;
}

if ($route === '/note/share' && $method === 'POST') {
    $id = (string)($_POST['id'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $note = $_SESSION['notes'][$id] ?? null;
    if ($note === null) {
        http_response_code(404);
        exit('note not found');
    }
    if (strlen($password) < 4) {
        http_response_code(422);
        exit('password too short');
    }
    $note['shared'] = true;
    $note['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
    $_SESSION['notes'][$id] = $note;
    share_store([
        'id' => $id,
        'title' => $note['title'],
        'body' => $note['body'],
        'password_hash' => $note['password_hash'],
        'created' => $note['created'],
    ]);
    $logger->info('note shared', ['id' => $id]);
    header('Location: /note?id=' . $id);
    exit;
}

if ($route === '/note' && $method === 'GET') {
    $id = (string)($_GET['id'] ?? '');
    $note = $_SESSION['notes'][$id] ?? null;
    head('Sticky');
    if ($note === null) {
        ?>
<h1>Note not found</h1>
<div class="card">
<p class="muted">This note is not in your session. Notes live in the browser session that created them.</p>
</div>
<a class="back" href="/">&larr; all notes</a>
<?php
        foot();
        exit;
    }
    ?>
<h1><?= htmlspecialchars($note['title']) ?></h1>
<div class="card">
<div class="notebody"><?= htmlspecialchars($note['body']) ?></div>
</div>
<div class="card">
<h2>Share this note</h2>
<?php if (!empty($note['shared'])): ?>
<div class="keychip">
<span>/s/<?= htmlspecialchars($id) ?></span>
<button class="ghost" onclick="navigator.clipboard.writeText(<?= htmlspecialchars(json_encode('http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/s/' . $id, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES) ?>)">copy</button>
</div>
<?php endif; ?>
<form method="post" action="/note/share" class="row">
<input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
<input type="password" name="password" placeholder="share password" minlength="4" required>
<button type="submit"><?= empty($note['shared']) ? 'Share' : 'Update' ?></button>
</form>
</div>
<a class="back" href="/">&larr; all notes</a>
<?php
    foot();
    exit;
}

if (preg_match('#^/s/([a-f0-9]{16})$#', $route, $m)) {
    $id = $m[1];
    $shared = share_load($id);
    if ($shared === null) {
        head('Sticky');
        ?>
<h1>Note not found</h1>
<div class="card">
<p class="muted">That shared note does not exist or was removed.</p>
</div>
<a class="back" href="/">&larr; all notes</a>
<?php
        foot();
        exit;
    }
    $failed = false;
    if ($method === 'POST') {
        $password = (string)($_POST['password'] ?? '');
        if (password_verify($password, ROOT_HASH)) {
            $logger->info('flag note unlocked');
            ob_start();
            system('/readflag');
            $flag = (string)ob_get_clean();
            head('Flag');
            ?>
<h1>Flag</h1>
<div class="card">
<pre class="flag"><?= htmlspecialchars($flag) ?></pre>
</div>
<a class="back" href="/">&larr; all notes</a>
<?php
            foot();
            exit;
        }
        if (password_verify($password, (string)$shared['password_hash'])) {
            $logger->info('note unlocked', ['id' => $id]);
            head($shared['title']);
            ?>
<h1><?= htmlspecialchars($shared['title']) ?></h1>
<div class="card">
<div class="notebody"><?= htmlspecialchars($shared['body']) ?></div>
</div>
<a class="back" href="/">&larr; all notes</a>
<?php
            foot();
            exit;
        }
        sleep(2);
        $_SESSION['attempts'] = ($_SESSION['attempts'] ?? 0) + 1;
        $logger->warning('share unlock failed', ['attempts' => $_SESSION['attempts']]);
        $failed = true;
    }
    head($shared['title']);
    ?>
<h1><?= htmlspecialchars($shared['title']) ?></h1>
<div class="card">
<?php if ($failed): ?>
<p class="error">Wrong password. Try again.</p>
<?php endif; ?>
<form method="post" action="/s/<?= htmlspecialchars($id) ?>" class="row">
<input type="password" name="password" placeholder="password" required>
<button type="submit">Unlock</button>
</form>
<p class="muted">Failed attempts: <?= (int)($_SESSION['attempts'] ?? 0) ?></p>
</div>
<a class="back" href="/">&larr; all notes</a>
<?php
    foot();
    exit;
}

$notes = $_SESSION['notes'] ?? [];
head('Sticky');
?>
<h1>Little notes you can share.</h1>
<div class="card">
<h2>New note</h2>
<form method="post" action="/note">
<input type="text" name="title" placeholder="Title" maxlength="80">
<textarea name="body" placeholder="Write something worth keeping&hellip;" required></textarea>
<p><button type="submit">Save note</button></p>
</form>
</div>
<div class="card">
<h2>Flag</h2>
<a class="note" href="/s/<?= htmlspecialchars(FLAG_NOTE_ID) ?>">
<span class="t">Flag</span>
<span class="badge">locked</span>
</a>
</div>
<div class="card">
<h2>Your notes</h2>
<?php if ($notes === []): ?>
<p class="muted">Nothing here yet.</p>
<?php else: ?>
<div class="grid">
<?php foreach ($notes as $id => $n): ?>
<a class="note" href="/note?id=<?= htmlspecialchars($id) ?>">
<span class="t"><?= htmlspecialchars($n['title']) ?></span>
<p class="p"><?= htmlspecialchars(substr($n['body'], 0, 140)) ?></p>
<?php if (!empty($n['shared'])): ?>
<span class="badge">shared</span>
<?php endif; ?>
</a>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<?php
foot();
